namespace Casino.DataStructures;

public enum RouletteBettingType {
    Red, Black, Even, Odd, High, Low, First12, Second12, Third12, Number
}