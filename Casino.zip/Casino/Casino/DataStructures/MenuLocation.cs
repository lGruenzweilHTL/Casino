namespace Casino.DataStructures;

public enum MenuLocation {
    Blackjack, Kings, SlotMachine, Roulette, Quit
}